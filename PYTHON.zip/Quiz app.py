# the json module to work with json files 
import json
import tkinter
from tkinter import *
import random

# load questions and answer choices from json file instead of the file
with open('./data.json', encoding="utf8") as f:
    data = json.load(f)

# convert the dictionary in lists of questions and answers_choice 
questions = [v for v in data[0].values()]
answers_choice = [v for v in data[1].values()]
correct_answer = [v for v in data[2].values()]

user_answer = []

indexes = []
def gen():
    global indexes
    while(len(indexes) < 5):
        x = random.randint(0,9)
        if x in indexes:
            continue
        else:
            indexes.append(x)

def quit():
    global btnPlayAgain
    btnQuit = Button(
    root,
    text = 'QUIT',
    bg='red',
    fg='white',
    height =2,
    width =5,
    font = ("Calibri", 12,"bold"),
    relief = FLAT,
    border = 0,
    command = root.destroy,
    )
    btnQuit.pack()
    btnQuit.place(x=320,y=520)

def showresult(score):
    lblQuestion.destroy()
    r1.destroy()
    r2.destroy()
    r3.destroy()
    r4.destroy()
    btnNext.destroy()
    global labelimage, labelresulttext, btnQuit
    labelimage = Label(
        root,
        background = "#66b3ff",
        border = 0,
    )
    labelimage.pack(pady=(50,30))
    labelresulttext = Label(
        root,
        font = ("Calibri",25,"bold"),
        background = "#66b3ff",
    )
    labelresulttext.pack()
    if score == 5:
        
        img = PhotoImage(file="great.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="5/5You Are Excellent !!")  
        quit()

    elif (score == 4):
        img = PhotoImage(file="ok.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="\n4/5\nYou Can Do Better !!")
        quit()

    elif (score == 3):
        img = PhotoImage(file="ok.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="\n3/5\nYou Can Do Better !!")
        quit()

    elif (score == 2):
        img = PhotoImage(file="ok.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="\n2/5\nYou Can Do Better !!")
        quit()

    elif (score == 1):
        img = PhotoImage(file="sad.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="\n1/5\nYou Should Work Hard !!")
        quit()

    else:
        img = PhotoImage(file="sad.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="\n0/0\nYou Should Work Harder !!")
        quit()

def calc():
    global indexes,user_answer,answers
    x = 0
    score = 0
    for i in indexes:
        if user_answer[x] == correct_answer[i]:
            score = score + 1
        x += 1
    showresult(score)

ques = 1
def selected():
    global radiovar,user_answer
    global lblQuestion,r1,r2,r3,r4
    global ques
    x = radiovar.get()
    user_answer.append(x)
    radiovar.set(-1)
    if ques < 5:
        lblQuestion.config(text= questions[indexes[ques]])
        r1['text'] = answers_choice[indexes[ques]][0]
        r2['text'] = answers_choice[indexes[ques]][1]
        r3['text'] = answers_choice[indexes[ques]][2]
        r4['text'] = answers_choice[indexes[ques]][3]
        ques += 1
    else:
        calc()
    
def startquiz():
    global lblQuestion,r1,r2,r3,r4,btnNext
    lblQuestion = Label(
        root,
        text = questions[indexes[0]],
        font = ("Calibri", 20,"bold"),
        width = 500,
        justify = "center",
        wraplength = 400,
        background = "#66b3ff",
    )
    lblQuestion.pack(pady=(100,30))

    global radiovar
    radiovar = IntVar()
    radiovar.set(-1)

    r1 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][0],
        font = ("Calibri", 20,"bold"),
        value = 0,
        variable = radiovar,
        
        background = "#66b3ff",
    )
    r1.pack(pady=5)

    r2 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][1],
        font = ("Calibri", 20,"bold"),
        value = 1,
        variable = radiovar,
        
        background = "#66b3ff",
    )
    r2.pack(pady=5)

    r3 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][2],
        font = ("Calibri", 20,"bold"),
        value = 2,
        variable = radiovar,
        
        background = "#66b3ff",
    )
    r3.pack(pady=5)

    r4 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][3],
        font = ("Calibri", 20,"bold"),
        value = 3,
        variable = radiovar,
        
        background = "#66b3ff",

    )
    r4.pack(pady=5)
    
    btnNext = Button(
    root,
    text='NEXT',
    width = 10,
    bg='darkblue',
    fg='white',
    activebackground='white',
    font=("Calibri",10,'bold'),
    height = 2,
    relief = FLAT,
    border = 0,
    command = selected,
    )
    btnNext.pack()
    btnNext.place(x=600,y=450)

def startIspressed():
    labelimage.destroy()
    labeltext.destroy()
    lblRules.destroy()
    btnStart.destroy()
    gen()
    startquiz()

root = tkinter.Tk()
root.title("Quiz App")
root.geometry("700x800")
root.config(background="#66b3ff")
root.resizable(0,0)


img1 = PhotoImage(file="Q logo.png")
labelimage = Label(
    root,
    image = img1,
    background = "#66b3ff",
)
labelimage.pack(pady=(0,0))

labeltext = Label(
    root,
    text = "Quiz App",
    font = ("Calibri",24,"bold"),
    background = "#66b3ff",
)
labeltext.pack(pady=(0,20))

img2 = PhotoImage(file="Start.png")
btnStart = Button(
    root,
    image = img2,
    relief = FLAT,
    border = 0,
    bg="#66b3ff",
    command = startIspressed,
)
btnStart.pack(padx=(10,0))

lblRules = Label(
    root,
    text = "      Zoya Mansoori(57)\nShazia Sajid(59)\n             Mohd. Sakib Shaikh(43)",
    width = 300,
    justify="center",
    font = ("Times",20),
    background = "black",
    foreground = "#FACA2F",
)
lblRules.pack()

root.mainloop()
